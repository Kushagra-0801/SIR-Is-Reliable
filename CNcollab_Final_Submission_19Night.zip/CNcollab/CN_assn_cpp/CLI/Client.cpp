#include <bits/stdc++.h>
// #include "RelUDP.hpp"
// #include "receive.hpp"
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pthread.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <unistd.h>
#include <fcntl.h>
#include "RelUDP.hpp"


string temp="";
void convert_file_name(char *file_name)
{
	int len=strlen(file_name);
	if(len<=43)
	{
		temp="";
		for(int i=0;i<len;i++)
			temp+=file_name[i];
		return;
	}
	char pref1=254;
	char pref2=253;
	int number_of_packets=(len+40)/41; // taking ceil
	for(int i=0;i<number_of_packets-1;i++)
	{
		temp+=pref1;
		temp+=pref2;
		for(int j=i*41;j<i*41+41;j++)
			temp+=file_name[j];
	}
	for(int i=(number_of_packets-1)*41;i<len;i++)
		temp+=file_name[i];
}

int main(int argc, char *argv[])
{
	char file_name[256]="";
	strcpy(file_name, argv[1]);

	char *final_file_name;
	convert_file_name(file_name);
	final_file_name=(char*)temp.c_str();

	cout<<"original file length: "<<strlen(file_name)<<"\n";
	cout<<"converted file length: "<<strlen(final_file_name)<<"\n";
	cout<<final_file_name<<"\n";
	rel_send((unsigned char*)final_file_name, strlen(final_file_name));


	unsigned char output[1000000];
	int data_size=0;
    rel_recv(output, &data_size);
    FILE *ptr=fopen("file_received.txt", "w");
    for(int i=0;i<data_size;i++)
    	fprintf(ptr, "%c", output[i]);
    return 0;
}