#include <bits/stdc++.h>
#include <openssl/md5.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

struct tt_packet
{
	unsigned int seq_no;
	unsigned char checksum[16];
	bool ack, nck;
	int length;
	unsigned char data[43];
};
typedef struct tt_packet Packet;

void create_md5_hash(const unsigned char* data, unsigned char* digest, int length)
{
    MD5((unsigned char*)data, length, (unsigned char*)digest);  
}

void print_md5_hash(unsigned char* data){
    for(int i = 0; i < 16; i++)
       printf("%02x ",(unsigned int)data[i]);
    printf("\n");
}

void intToByte(int n, unsigned char *str)
{
	for(int i=3;i>=0;i--)
	{
		str[i]=(n >> (8*i)) & 0xFF;
	}
}

int byteToInt(unsigned char *byte)
{
	int n=0;
    n=n+(byte[0] & 0x000000ff);
    n=n+((byte[1] & 0x000000ff) << 8);
    n=n+((byte[2] & 0x000000ff) << 16);
    n=n+((byte[3] & 0x000000ff) << 24);
    return n;
}

void printPacket(Packet *p)
{
	cout<<"Sequence no: "<<p->seq_no<<"\n";
	// cout<<"Checksum: "<<p->checksum<<"\n";
	cout<<"Ack: "<<p->ack<<" "<<"nck: "<<p->nck<<"\n";
	cout<<"Length: "<<p->length<<"\n";
	// cout<<"Data: ";
	for(int i=0;i<p->length;i++)
		cout<<p->data[i];
}
static void packetToArray(Packet *packet, unsigned char *pk_array)
{
	int k=0;

	// sequence number
	// intToByte(packet->seq_no, pk_array+k);
	intToByte(htonl(packet->seq_no), pk_array+k);
	k+=4;

	// checksum
	for(int i=0;i<16;i++)
	{
		pk_array[k]=packet->checksum[i];
		k++;
	}

	// flags
	int flag=(packet->ack<<7)+(packet->nck<<6)+packet->length;
	pk_array[k]=(flag & 0xFF);
	k++;

	// data
	for(int i=0;i<packet->length;i++)
	{
		pk_array[k]=packet->data[i];
		k++;
	}

}
static void arrayToPacket(Packet *packet, unsigned char *pk_array)
{
	int k=0;

	// sequence number
	// packet->seq_no=byteToInt(pk_array);
	packet->seq_no=ntohl(byteToInt(pk_array));
	k+=4;

	// checksum
	for(int i=0;i<16;i++)
	{
		packet->checksum[i]=pk_array[k];
		k++;
	}

	// flags
	int x=pk_array[k];
	k++;
	packet->ack=(x & (1<<7));
	packet->nck=(x & (1<<6));
	packet->length=(x & ((1<<6)-1));

	// data
	for(int i=0;i<packet->length;i++)
	{
		packet->data[i]=pk_array[k];
		k++;
	}
}