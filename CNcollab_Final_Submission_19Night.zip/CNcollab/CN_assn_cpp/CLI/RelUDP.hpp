#include <bits/stdc++.h>
// #include "Packet.hpp"
#include <chrono>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <openssl/md5.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#include <unistd.h>
#include <fcntl.h>

#include "Packet.hpp"


#define sz(QQQ) (int)QQQ.size()
# define TIMER 3


// class RelUDP
// {
// public:
	string ip_addr;
	int port_no=9090;
	int window=50;
	int socketfd;
	struct sockaddr_in server_address;
	int number_of_packets;
	int lost_packets;
	int send_next;

	map<int, int> ack;
	map<int, Packet> mp;

	int has_received=0;

	
	

	// RelUDP(string ip, int port)
	// {
	// 	port_no=9999;
	// 	ip_addr=ip;

	// 	window=128;
	// 	socketfd=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	// 	server_address.sin_family=AF_INET;
	// 	server_address.sin_port=htons(port_no);
	// 	server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());
	// }

	int checkSum(Packet *p)
	{
		unsigned char str[16];
		create_md5_hash(p->data, str, p->length);
		// print_md5_hash(p->checksum);
		// print_md5_hash(str);
		for(int i=0;i<16;i++)
			if(str[i]!=p->checksum[i])
				return 0;
		return 1;
	}

	void sendLastPacket()
	{
		RESEND:
		Packet last;
		last.seq_no=number_of_packets;
		last.ack=1;
		last.nck=1;
		memset(last.data, 0, sizeof(last.data));
		char msg[]="TEKCAP TSAL";
		last.length=strlen(msg);
		strcpy((char*)last.data, msg);
		create_md5_hash(last.data, last.checksum, last.length);
		//cout<<last.length<<"\n";
		unsigned char last_arr[64];
		packetToArray(&last, last_arr);

		auto start = std::chrono::system_clock::now();
		sendto(socketfd, (const unsigned char *)last_arr, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=last.seq_no;
		while(ack[seq]<=0 && elapsed_seconds.count()<1)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		else
			cout<<"ack received for sequence number: "<<seq<<"\n";
	}

	void *receiveAck()
	{
		while(ack[number_of_packets-1]==0)
		{
			unsigned char temp[64];
			socklen_t len=sizeof(server_address);

			// cout<<"details where receiving the data: \n";
			// cout<<server_address.sin_family<<" ";
			// cout<<server_address.sin_port<<" ";
			// cout<<server_address.sin_addr.s_addr<<"\n";

			struct sockaddr_in temp_address;
			temp_address=server_address;

			// cout<<"Details for receiving data: \n";
			// cout<<server_address.sin_family<<" ";
			// cout<<server_address.sin_port<<" ";
			// cout<<server_address.sin_addr.s_addr<<" ";
			// cout<<socketfd<<"\n";

			int n = recvfrom(socketfd, (unsigned char *)temp, 64, 0, ( struct sockaddr *) &server_address, &len);

			server_address=temp_address;

			Packet received_packet;
			arrayToPacket(&received_packet, temp);
			if(received_packet.ack==1 && received_packet.nck==1)
		    {
		    		int flag = 1;
		    		// if(received_packet.length != 11)
		    		// 	continue;
		    		// for(int i = 0; i < 11; i++)
		    		// {
		    		// 	if(received_packet.data[i] != msg[i])
		    		// 		flag = 0;
		    		// }
		    		// if(flag == 0)
		    		// 	continue;
		    		cout << "Last packet received\n";
		    		ack[0] = 1;
		    		has_received = 1;
    				if(!checkSum(&received_packet))
    				{
    					cout<<"checksum not matching\n";
    					Packet nck_packet;
    					memset(nck_packet.data, 0, sizeof(nck_packet));
    					nck_packet.ack=0;
    					nck_packet.nck=1;
    					nck_packet.seq_no=received_packet.seq_no;
    					nck_packet.length=0;
    					create_md5_hash(nck_packet.data, nck_packet.checksum, nck_packet.length);
    					unsigned char send_ack[64];
    					packetToArray(&nck_packet, send_ack);
    					sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
    					continue;
    				}
    				Packet ack_packet;
    				memset(ack_packet.data, 0, sizeof(ack_packet));
    				ack_packet.ack=1;
    				ack_packet.nck=0;
    				ack_packet.seq_no=received_packet.seq_no;
    				ack_packet.length=0;
    				create_md5_hash(ack_packet.data, ack_packet.checksum, ack_packet.length);
    				unsigned char send_ack[64];
    				packetToArray(&ack_packet, send_ack);
    				sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
    				char msg[]="TEKCAP TSAL";
    		    	//received_packet.data[received_packet.length]='\0';
		    		break;
		    		// cout<<"got the last packet\n";
		    }
			if(received_packet.ack==1)
			{
				send_next=1;
				ack[received_packet.seq_no]=received_packet.ack;
			}
			else if(received_packet.nck==1)
				ack[received_packet.seq_no]=-1;
			else
			{
				//cout << ("Printing packet 0 000 0\n");
				//printPacket(&received_packet);
				cout << "Receive cnt " << mp.size() << "\n";
				mp[received_packet.seq_no]=received_packet;
				if(!checkSum(&received_packet))
				{
					cout<<"checksum not matching\n";
					Packet nck_packet;
					memset(nck_packet.data, 0, sizeof(nck_packet));
					nck_packet.ack=0;
					nck_packet.nck=1;
					nck_packet.seq_no=received_packet.seq_no;
					nck_packet.length=0;
					create_md5_hash(nck_packet.data, nck_packet.checksum, nck_packet.length);
					unsigned char send_ack[64];
					packetToArray(&nck_packet, send_ack);
					sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
					continue;
				}
				Packet ack_packet;
				memset(ack_packet.data, 0, sizeof(ack_packet));
				ack_packet.ack=1;
				ack_packet.nck=0;
				ack_packet.seq_no=received_packet.seq_no;
				ack_packet.length=0;
				create_md5_hash(ack_packet.data, ack_packet.checksum, ack_packet.length);
				unsigned char send_ack[64];
				packetToArray(&ack_packet, send_ack);
				sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
				char msg[]="TEKCAP TSAL";
		    	//received_packet.data[received_packet.length]='\0';

		    	
			}
		}
		return NULL;
	}
	void sendPacket(pair<unsigned char*, int> temp)
	{
		cout<<"sending packet with sequence number: "<<temp.second<<"\n";
		RESEND:
		auto start = std::chrono::system_clock::now();

		

		sendto(socketfd, (const unsigned char *)temp.first, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=temp.second;
		//cout << seq << " " << ack[seq] << "\n";
		while(ack[seq]<=0 && elapsed_seconds.count()< TIMER)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			lost_packets++;
			cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		else
			cout<<"ack received for sequence number: "<<seq<<"\n";
	}

	void rel_send(unsigned char *input, int length)
	{
		cout<<"sending file: "<<input<<"\n";
		socketfd=socket(AF_INET, SOCK_DGRAM, 0);

		server_address.sin_family=AF_INET;
		server_address.sin_port=htons(port_no);
		server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());

		int connection_status=connect(socketfd, (struct sockaddr*) &server_address, sizeof(server_address));
		if(connection_status==-1)
		{
		    printf("could not connect properly\n");
		    return;
		}

		ack.clear();
		lost_packets=0;

		number_of_packets=(length+42)/43; // taking ceil
		unsigned char p_array[number_of_packets][64];

		Packet packet[number_of_packets];

		for(int i=0;i<number_of_packets;i++)
		{
			Packet p;
			packet[i].seq_no=i;
			packet[i].ack=0;
			packet[i].nck=0;
			packet[i].length=min(43, length-i*43);
			if(i==(number_of_packets-1))
			{
				packet[i].ack=1;
				packet[i].nck=1;
			}
			for(int j=i*43;j<i*43+packet[i].length;j++)
				packet[i].data[j-i*43]=input[j];
			create_md5_hash(packet[i].data, packet[i].checksum, packet[i].length);
			packetToArray(&packet[i], p_array[i]);
		}
		int left=0, right=0;
		thread myThreads[number_of_packets];
		thread th_ack(receiveAck);
		send_next=0;
		for(int i=0;i<min(window, number_of_packets);i++)
		{
			pair<unsigned char*, int> temp=make_pair(p_array[i], packet[i].seq_no);
			myThreads[i]=thread(sendPacket, temp);
		}
		int k=window;
		while(1)
		{
			if(send_next==0)
				continue;
			if(k>=number_of_packets)
				break;
			pair<unsigned char*, int> temp=make_pair(p_array[k], packet[k].seq_no);
			myThreads[k]=thread(sendPacket, temp);
			send_next=0;
			k++;
			// myThreads[i].detach();
		}
		cout<<"Waiting for all threads to finish before sending last packet...\n";
		for(int i=0;i<number_of_packets;i++)
		{
			if(myThreads[i].joinable())
			{
				// cout<<"thread "<<i<<"finished\n";
				myThreads[i].join();
			}
		}
		cout<<"received acks for all packets\n";
		// sendLastPacket();
		if(th_ack.joinable())
			th_ack.join();
		cout<<"total number of packets: "<<number_of_packets<<", number of lost packets: "<<lost_packets<<"\n";
		// close(socketfd);
	}





	

	void rel_recv(unsigned char *output_data, int *data_size)
	{
		// int socketfd=socket(AF_INET, SOCK_DGRAM, 0);
		// struct sockaddr_in servaddr, cliaddr;
		// memset(&cliaddr, 0, sizeof(cliaddr));
		// memset(&servaddr, 0, sizeof(servaddr));

		// servaddr.sin_family=AF_INET;
		// servaddr.sin_port=htons(9090);
		// servaddr.sin_addr.s_addr=INADDR_ANY;

		// if(bind(socketfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 )
	 //    {
	 //        perror("bind failed");
	 //        exit(EXIT_FAILURE);
	 //    }
	    unsigned char buffer[64];

	    socklen_t len=sizeof(server_address);

	    // int flags = fcntl(socketfd, F_GETFL);
	    // flags |= O_NONBLOCK;
	    // fcntl(socketfd, F_SETFL, flags);
	    // cout<<"started receiving\n";
	    int n=-1;

		cout << "has_received ack for file name" << "\n";
		int prev=-1;
		while(1)
		{
			if(has_received==1)
				break;
	        // cout<<"started receiving...\n";

	        // cout<<"Details for receiving file data: \n";
	        // cout<<server_address.sin_family<<" ";
	        // cout<<server_address.sin_port<<" ";
	        // cout<<server_address.sin_addr.s_addr<<" ";
	        // cout<<socketfd<<"\n";
			cout << "Waiting for packet\n";
			int n=recvfrom(socketfd, (unsigned char *)buffer, 64, 0, (struct sockaddr *) &server_address, &len);

			// cout<<"details where receiving the file data: \n";
			// cout<<server_address.sin_family<<" ";
			// cout<<server_address.sin_port<<" ";
			// cout<<server_address.sin_addr.s_addr<<"\n";



			
	        // cout<<"ended receiving\n";
			Packet p;
	    	arrayToPacket(&p, buffer);
	    	// cout<<p.seq_no<<"\n";
	        // printPacket(&p);
	    	if(!checkSum(&p))
	    	{
	    		cout<<"checksum not matching\n";
	    		Packet nck_packet;
	    		memset(nck_packet.data, 0, sizeof(nck_packet));
	    		nck_packet.ack=0;
	    		nck_packet.nck=1;
	    		nck_packet.seq_no=p.seq_no;
	    		nck_packet.length=0;
	    		create_md5_hash(nck_packet.data, nck_packet.checksum, nck_packet.length);
	    		unsigned char send_ack[64];
	    		packetToArray(&nck_packet, send_ack);
	    		sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
	    		continue;
	    	}
	    	Packet ack_packet;
	    	memset(ack_packet.data, 0, sizeof(ack_packet));
	    	ack_packet.ack=1;
	    	ack_packet.nck=0;
	    	ack_packet.seq_no=p.seq_no;
	    	ack_packet.length=0;
	    	create_md5_hash(ack_packet.data, ack_packet.checksum, ack_packet.length);
	    	unsigned char send_ack[64];
	    	packetToArray(&ack_packet, send_ack);
	    	sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
	    	char msg[]="TEKCAP TSAL";
	    	p.data[p.length]='\0';
	    	if(p.ack==1 && p.nck==1 && (strcmp((char*)p.data, msg)==0))
	    	{
	    		// cout<<"got the last packet\n";
	    		break;
	    	}
	    	mp[p.seq_no]=p;
		}
		string temp="";
		int k=0;
		for(auto it: mp)
		{
			if(k==0)
			{
				k++;
				continue;
			}
			for(int j=0;j<it.second.length;j++)
			{
				// cout<<it.second.data[j];
				output_data[k]=it.second.data[j];
				temp+=(it.second.data[j]);
				k++;
			}
		}
		// cout<<temp<<"\n";
		// output_data[k]='\0';
		for(int i=0;i<(int)temp.size();i++)
		{
			output_data[i]=temp[i];
			// cout<<output_data[i]<<"---"<<temp[i]<<"\n";
		}
		*data_size=(int)temp.size();
		// cout<<"size of output_data: "<<strlen((char*)output_data)<<"\n";
		//cout<<k<<"\n";
		//cout<<"size of map: "<<mp.size()<<"\n";
		cout<<"ended receiving\n";
	    // close(socketfd);
	}