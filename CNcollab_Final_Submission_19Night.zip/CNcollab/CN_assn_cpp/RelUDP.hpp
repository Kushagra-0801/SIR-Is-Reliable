#include <bits/stdc++.h>
#include "Packet.hpp"
#include <chrono>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <openssl/md5.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>


#define sz(QQQ) (int)QQQ.size()


// class RelUDP
// {
// public:
	string ip_addr;
	int port_no=9090;
	int window=50;
	int socketfd=socket(AF_INET, SOCK_DGRAM, 0);;
	struct sockaddr_in server_address;
	int number_of_packets;
	int lost_packets;
	int send_next;

	map<int, int> ack;

	void create_md5_hash(const unsigned char* data, unsigned char* digest, int length)
	{
	    MD5((unsigned char*)data, length, (unsigned char*)digest);  
	}

	void print_md5_hash(unsigned char* data){
	    for(int i = 0; i < 16; i++)
	       printf("%02x ",(unsigned int)data[i]);
	    printf("\n");
	}
	

	// RelUDP(string ip, int port)
	// {
	// 	port_no=9999;
	// 	ip_addr=ip;

	// 	window=128;
	// 	socketfd=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	// 	server_address.sin_family=AF_INET;
	// 	server_address.sin_port=htons(port_no);
	// 	server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());
	// }

	void sendLastPacket()
	{
		RESEND:
		Packet last;
		last.seq_no=number_of_packets;
		last.ack=1;
		last.nck=1;
		memset(last.data, 0, sizeof(last.data));
		char msg[]="TEKCAP TSAL";
		last.length=strlen(msg);
		strcpy((char*)last.data, msg);
		create_md5_hash(last.data, last.checksum, last.length);
		cout<<last.length<<"\n";
		unsigned char last_arr[64];
		packetToArray(&last, last_arr);

		auto start = std::chrono::system_clock::now();
		sendto(socketfd, (const unsigned char *)last_arr, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=last.seq_no;
		while(ack[seq]<=0 && elapsed_seconds.count()<1)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			// cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		// else
			// cout<<"ack received for sequence number: "<<seq<<"\n";
	}

	void *receiveAck()
	{
		while(ack[number_of_packets]==0)
		{
			unsigned char temp[64];
			socklen_t len=sizeof(server_address);
			int n = recvfrom(socketfd, (unsigned char *)temp, 64, 0, ( struct sockaddr *) &server_address, &len);
			Packet received_packet;
			arrayToPacket(&received_packet, temp);
			if(received_packet.nck==0)
			{
				send_next=1;
				ack[received_packet.seq_no]=received_packet.ack;
			}
			else
				ack[received_packet.seq_no]=-1;
		}
		return NULL;
	}
	void sendPacket(pair<unsigned char*, int> temp)
	{
		// cout<<"sending packet with sequence number: "<<temp.second<<"\n";
		RESEND:
		auto start = std::chrono::system_clock::now();
		sendto(socketfd, (const unsigned char *)temp.first, 64, 0, (const struct sockaddr *) &server_address, sizeof(server_address));
		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=temp.second;

		while(ack[seq]<=0 && elapsed_seconds.count()<1)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			lost_packets++;
			// cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		// else
			// cout<<"ack received for sequence number: "<<seq<<"\n";
	}

	void sendP(unsigned char *input, int length)
	{
		server_address.sin_family=AF_INET;
		server_address.sin_port=htons(port_no);
		server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());

		ack.clear();
		lost_packets=0;

		number_of_packets=(length+42)/43; // taking ceil
		unsigned char p_array[number_of_packets][64];

		Packet packet[number_of_packets];

		for(int i=0;i<number_of_packets;i++)
		{
			Packet p;
			packet[i].seq_no=i;
			packet[i].ack=0;
			packet[i].nck=0;
			packet[i].length=min(43, length-i*43);
			for(int j=i*43;j<i*43+packet[i].length;j++)
				packet[i].data[j-i*43]=input[j];
			create_md5_hash(packet[i].data, packet[i].checksum, packet[i].length);
			packetToArray(&packet[i], p_array[i]);
		}
		int left=0, right=0;
		thread myThreads[number_of_packets];
		thread th_ack(receiveAck);
		send_next=0;
		for(int i=0;i<min(window, number_of_packets);i++)
		{
			pair<unsigned char*, int> temp=make_pair(p_array[i], packet[i].seq_no);
			myThreads[i]=thread(sendPacket, temp);
		}
		int k=window;
		while(1)
		{
			if(send_next==0)
				continue;
			if(k>=number_of_packets)
				break;
			pair<unsigned char*, int> temp=make_pair(p_array[k], packet[k].seq_no);
			myThreads[k]=thread(sendPacket, temp);
			send_next=0;
			k++;
			// myThreads[i].detach();
		}
		cout<<"Waiting for all threads to finish before sending last packet...\n";
		for(int i=0;i<number_of_packets;i++)
		{
			if(myThreads[i].joinable())
			{
				// cout<<"thread "<<i<<"finished\n";
				myThreads[i].join();
			}
		}
		cout<<"received acks for all packets\n";
		sendLastPacket();
		if(th_ack.joinable())
			th_ack.join();
		cout<<"total number of packets: "<<number_of_packets<<", number of lost packets: "<<lost_packets<<"\n";
	}