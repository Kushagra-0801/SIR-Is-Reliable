#include <bits/stdc++.h>
#include <chrono>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <openssl/md5.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include "Packet.hpp"


#define sz(QQQ) (int)QQQ.size()


// class RelUDP
// {
// public:
	string ip_addr;
	int port_no=9090;
	int socketfd;
	int window=50;
	// struct sockaddr_in server_address;
	struct sockaddr_in server_address, cliaddr;
	int number_of_packets;
	int lost_packets;
	int send_next;

	map<int, int> ack;
	int size_of_file;
	int total_acks_recv=0;
	
	

	// RelUDP(string ip, int port)
	// {
	// 	port_no=9999;
	// 	ip_addr=ip;

	// 	window=128;
	// 	socketfd=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	// 	server_address.sin_family=AF_INET;
	// 	server_address.sin_port=htons(port_no);
	// 	server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());
	// }

	void sendLastPacket()
	{
		RESEND:
		Packet last;
		last.seq_no=number_of_packets+2;
		last.ack=1;
		last.nck=1;
		memset(last.data, 0, sizeof(last.data));
		char msg[]="TEKCAP TSAL";
		last.length=strlen(msg);
		strcpy((char*)last.data, msg);
		create_md5_hash(last.data, last.checksum, last.length);
		// cout<<last.length<<"\n";
		unsigned char last_arr[64];
		packetToArray(&last, last_arr);
		// printPacket(&last);

		auto start = std::chrono::system_clock::now();
		cout<<"sending first packet containing ack 1 nak 1 Acks recvd: " << total_acks_recv << "\n";
		sendto(socketfd, (const unsigned char *)last_arr, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
		// printPacket(&last);
		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=last.seq_no;
		while(ack[seq]<=0 && elapsed_seconds.count()<1)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			cout << "Acks recvd: " << total_acks_recv << "\n";
			cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		else
		{
			cout << "Acks recvd: " << total_acks_recv << "\n";
			cout<<"ack received for sequence number: "<<seq<<"\n";
		}
	}
	void *receiveAck()
	{
		while(total_acks_recv!=(number_of_packets+1))
		{
			unsigned char temp[64];
			socklen_t len=sizeof(cliaddr);


			int n = recvfrom(socketfd, (unsigned char *)temp, 64, 0, ( struct sockaddr *) &cliaddr, &len);
			Packet received_packet;
			arrayToPacket(&received_packet, temp);
			if(received_packet.seq_no == 0)
			{
				//printPacket(&received_packet);
			}
			if(received_packet.ack == 1 && received_packet.nck == 1)
			{
				Packet temp;
				temp.seq_no=received_packet.seq_no;
				temp.ack=1;
				temp.nck=0;
				temp.length=0;
				create_md5_hash(temp.data, temp.checksum, temp.length);
				unsigned char temp_array[64];
				packetToArray(&temp, temp_array);
				sendto(socketfd, (const unsigned char *)temp_array, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
			
				// send_next=1;
				// if(ack[received_packet.seq_no]==0 && received_packet.ack==1)
				// {
				// 	total_acks_recv++;
				// }
				// ack[received_packet.seq_no]=received_packet.ack;				
			}
			else if(received_packet.ack == 0 && received_packet.nck == 1)
			{
				ack[received_packet.seq_no]=-1;
			}
			else if(received_packet.ack==0 && received_packet.nck == 0)
			{
				Packet temp;
				temp.seq_no=received_packet.seq_no;
				temp.ack=1;
				temp.nck=0;
				temp.length=0;
				create_md5_hash(temp.data, temp.checksum, temp.length);
				unsigned char temp_array[64];
				packetToArray(&temp, temp_array);
				sendto(socketfd, (const unsigned char *)temp_array, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
			}
			else
			{
				send_next=1;
				if(ack[received_packet.seq_no]==0 && received_packet.ack==1)
				{
					total_acks_recv++;
				}
				ack[received_packet.seq_no]=received_packet.ack;	
			}
		}
		return NULL;
	}
	void sendPacket(pair<unsigned char*, int> temp)
	{
		// cout<<"sending packet with sequence number: "<<temp.second<<"\n";
		RESEND:
		auto start = std::chrono::system_clock::now();

		// cout<<"Client details: \n";
		// cout<<cliaddr.sin_family<<" ";
		// cout<<cliaddr.sin_port<<" ";
		// cout<<cliaddr.sin_addr.s_addr<<" ";
		// cout<<socketfd<<"\n";

		sendto(socketfd, (const unsigned char *)temp.first, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
		Packet temp_packet;
		arrayToPacket(&temp_packet, temp.first);
		cout << "Acks recvd: " << total_acks_recv << "\n";
		// printPacket(&temp_packet);

		// cout<<"Client details: \n";
		// cout<<cliaddr.sin_family<<" ";
		// cout<<cliaddr.sin_port<<" ";
		// cout<<cliaddr.sin_addr.s_addr<<"\n";

		auto end = std::chrono::system_clock::now();
		std::chrono::duration<double> elapsed_seconds = end-start;
		int seq=temp.second;

		while(ack[seq]<=0 && elapsed_seconds.count()<1)
		{
			if(ack[seq]==-1)
			{
				ack[seq]=0;
				goto RESEND;
			}
			auto current = std::chrono::system_clock::now();
			elapsed_seconds = current-start;
		}
		if(ack[seq]<=0)
		{
			lost_packets++;
			cout << "Acks recvd: " << total_acks_recv << "\n";
			cout<<"resending packet with sequence number: "<<seq<<"\n";
			goto RESEND;
		}
		else
		{
			cout << "Acks recvd: " << total_acks_recv << "\n";			
			cout<<"ack received for sequence number: "<<seq<<"\n";
		}
	}

	void rel_send(unsigned char *input, int length, int file_size)
	{
		size_of_file=file_size;
		// socketfd=socket(AF_INET, SOCK_DGRAM, 0);

		// server_address.sin_family=AF_INET;
		// server_address.sin_port=htons(port_no);
		// server_address.sin_addr.s_addr=INADDR_ANY;//inet_addr(ip_addr.c_str());

		// cout<<"Client details before sending file data: \n";
		// cout<<cliaddr.sin_family<<" ";
		// cout<<cliaddr.sin_port<<" ";
		// cout<<cliaddr.sin_addr.s_addr<<" ";
		// cout<<socketfd<<"\n";

		ack.clear();
		lost_packets=0;
		number_of_packets=(length+42)/43; // taking ceil
		unsigned char p_array[number_of_packets+1][64];

		Packet packet[number_of_packets+1];
		packet[0].seq_no=1;
		packet[0].ack=0;
		packet[0].nck=0;
		packet[0].length=4;
		file_size=htonl(file_size);
		intToByte(file_size, packet[0].data);
		create_md5_hash(packet[0].data, packet[0].checksum, packet[0].length);
		packetToArray(&packet[0], p_array[0]);

		


		for(int i=1;i<number_of_packets+1;i++)
		{
			Packet p;
			packet[i].seq_no=i+1;
			packet[i].ack=0;
			packet[i].nck=0;
			packet[i].length=min(43, length-(i-1)*43);
			for(int j=(i-1)*43;j<(i-1)*43+packet[i].length;j++)
				packet[i].data[j-((i-1)*43)]=input[j];
			create_md5_hash(packet[i].data, packet[i].checksum, packet[i].length);
			packetToArray(&packet[i], p_array[i]);
			// cout<<"\nprinting packet while making\n";
			// printPacket(&packet[i]);
		}
		int left=0, right=0;
		thread myThreads[number_of_packets+1];
		thread th_ack(receiveAck);
		send_next=0;
		for(int i=0;i<min(window, number_of_packets+1);i++)
		{
			pair<unsigned char*, int> temp=make_pair(p_array[i], packet[i].seq_no);
			myThreads[i]=thread(sendPacket, temp);
		}
		int k=window;
		// cout<<"number of packets: "<<number_of_packets<<"\n";
		while(1)
		{
			if(send_next==0)
				continue;
			if(k>=(number_of_packets+1))
				break;
			pair<unsigned char*, int> temp=make_pair(p_array[k], packet[k].seq_no);
			myThreads[k]=thread(sendPacket, temp);
			send_next=0;
			k++;
			// myThreads[i].detach();
		}
		cout<<"Waiting for all threads to finish before sending last packet...\n"<<flush;
		for(int i=0;i<number_of_packets+1;i++)
		{
			if(myThreads[i].joinable())
			{
				// cout<<"thread "<<i<<"finished\n";
				myThreads[i].join();
			}
		}
		cout<<"received acks for all packets\n";
		sendLastPacket();
		if(th_ack.joinable())
			th_ack.join();
		cout<<"total number of packets: "<<number_of_packets+1<<", number of lost packets: "<<lost_packets<<"\n";
		// close(socketfd);
	}


	int checkSum(Packet *p)
	{
		unsigned char str[16];
		create_md5_hash(p->data, str, p->length);
		// print_md5_hash(p->checksum);
		// print_md5_hash(str);
		for(int i=0;i<16;i++)
			if(str[i]!=p->checksum[i])
				return 0;
		return 1;
	}

	void rel_recv(unsigned char *output)
	{
		socketfd=socket(AF_INET, SOCK_DGRAM, 0);

		
		memset(&cliaddr, 0, sizeof(cliaddr));
		memset(&server_address, 0, sizeof(server_address));

		server_address.sin_family=AF_INET;
		server_address.sin_port=htons(9090);
		server_address.sin_addr.s_addr=INADDR_ANY;

		if(bind(socketfd, (const struct sockaddr *)&server_address, sizeof(server_address)) < 0 )
	    {
	        perror("bind failed");
	        exit(EXIT_FAILURE);
	    }
	    unsigned char buffer[64];

	    socklen_t len=sizeof(cliaddr);

	    // int flags = fcntl(socketfd, F_GETFL);
	    // flags |= O_NONBLOCK;
	    // fcntl(socketfd, F_SETFL, flags);
	    // cout<<"started receiving\n";
	    int n=-1;

		map<int, Packet> mp;
		while(1)
		{

			// cout<<"Client details: \n";
			// cout<<cliaddr.sin_family<<" ";
			// cout<<cliaddr.sin_port<<" ";
			// cout<<cliaddr.sin_addr.s_addr<<" ";
			// cout<<socket<<"\n";

			int n=recvfrom(socketfd, (unsigned char *)buffer, 64, 0, (struct sockaddr *) &cliaddr, &len);

			// cout<<"Client details: \n";
			// cout<<cliaddr.sin_family<<" ";
			// cout<<cliaddr.sin_port<<" ";
			// cout<<cliaddr.sin_addr.s_addr<<" ";
			// cout<<socket<<"\n";


			Packet p;
	    	arrayToPacket(&p, buffer);
	    	if(!checkSum(&p))
	    	{
	    		cout<<"checksum not matching\n";
	    		Packet nck_packet;
	    		memset(nck_packet.data, 0, sizeof(nck_packet));
	    		nck_packet.ack=0;
	    		nck_packet.nck=1;
	    		nck_packet.seq_no=p.seq_no;
	    		nck_packet.length=0;
	    		create_md5_hash(nck_packet.data, nck_packet.checksum, nck_packet.length);
	    		unsigned char send_ack[64];
	    		packetToArray(&nck_packet, send_ack);
	    		sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
	    		continue;
	    	}
	    	Packet ack_packet;
	    	memset(ack_packet.data, 0, sizeof(ack_packet));
	    	ack_packet.ack=1;
	    	ack_packet.nck=0;
	    	ack_packet.seq_no=p.seq_no;
	    	ack_packet.length=0;
	    	create_md5_hash(ack_packet.data, ack_packet.checksum, ack_packet.length);
	    	unsigned char send_ack[64];
	    	packetToArray(&ack_packet, send_ack);

	    	// cout<<"Client details: \n";
	    	// cout<<cliaddr.sin_family<<" ";
	    	// cout<<cliaddr.sin_port<<" ";
	    	// cout<<cliaddr.sin_addr.s_addr<<" ";
	    	// cout<<socketfd<<"\n";

	    	sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));

	    	// cout<<"Client details: \n";
	    	// cout<<cliaddr.sin_family<<" ";
	    	// cout<<cliaddr.sin_port<<" ";
	    	// cout<<cliaddr.sin_addr.s_addr<<" ";
	    	// cout<<socketfd<<"\n";

	    	char msg[]="TEKCAP TSAL";
	    	p.data[p.length]='\0';
	    	mp[p.seq_no]=p;
	    	if(p.ack==1 && p.nck==1)
	    	{
	    		// cout<<"got the last packet\n";
	    		break;
	    	}
		}
		int k=0;
		for(auto it: mp)
		{
			for(int j=0;j<it.second.length;j++)
			{
				output[k]=it.second.data[j];
				k++;
			}
		}
		output[k]='\0';
		// cout<<"Client details: \n";
		// cout<<cliaddr.sin_family<<" ";
		// cout<<cliaddr.sin_port<<" ";
		// cout<<cliaddr.sin_addr.s_addr<<" ";
		// cout<<socketfd<<"\n";
	    // close(socketfd);
	}