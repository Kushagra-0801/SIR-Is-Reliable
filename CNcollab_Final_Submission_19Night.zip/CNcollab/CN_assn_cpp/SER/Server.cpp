#include <bits/stdc++.h>
// #include "receive.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fstream>

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <fcntl.h> // for open
#include <unistd.h> // for close

#include <dirent.h>
#include <openssl/md5.h>


using namespace std;
#include "RelUDP.hpp"

string temp="";
void convert_file_name(char *file_name)
{
    int len=strlen(file_name);
    if(len<=43)
    {
        temp="";
        for(int i=0;i<len;i++)
            temp+=file_name[i];
        return;
    }
    temp="";
    int number_of_packets=(len+42)/43;
    for(int i=0;i<number_of_packets-1;i++)
    {
        for(int j=i*43+2;j<i*43+43;j++)
            temp+=file_name[j];
    }
    for(int i=(number_of_packets-1)*43;i<len;i++)
        temp+=file_name[i];
    // cout<<temp<<"\n";
}


int main()
{
    // create a socket
    // int client_socket;
    // client_socket=socket(AF_INET, SOCK_DGRAM, 0);

    // // specifying address for the socket
    // struct sockaddr_in server_address;
    // server_address.sin_family=AF_INET;
    // server_address.sin_port=htons(9999);
    // server_address.sin_addr.s_addr=INADDR_ANY;

    int socketfd;
    
    char file_name[256];
    rel_recv((unsigned char*)file_name);

    // cout<<"Client details just after receiving file name: \n";
    // cout<<cliaddr.sin_family<<" ";
    // cout<<cliaddr.sin_port<<" ";
    // cout<<cliaddr.sin_addr.s_addr<<" ";
    // cout<<socketfd<<"\n";

    char *final_file_name;
    convert_file_name(file_name);
    final_file_name=(char*)temp.c_str();
    cout<<"original file length: "<<strlen(file_name)<<"\n";
    cout<<final_file_name<<"\n";
    cout<<"converted file length: "<<strlen(final_file_name)<<"\n";

    



    unsigned char data[1000000];
    int k=0;
    char ch;
    FILE *ptr=fopen((char*)final_file_name, "r");

    cout<<"started seeking\n";
    fseek(ptr, 0, 2);
    int file_size=ftell(ptr);
    cout<<"ended seeking\n";
    cout<<file_size<<"\n"<<flush;

    fseek(ptr, 0, 0);
    while((ch=fgetc(ptr))!=EOF)
    {
    	data[k]=(unsigned char)ch;
    	k++;
    }
    data[k]='\0';
    // printf("%s", data);

    rel_send(data, k, file_size);

	printf("done\n");
	return 0;
}