#include <bits/stdc++.h>
#include "RelUDP.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fstream>

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <fcntl.h> // for open
#include <unistd.h> // for close

#include <dirent.h>
#include <openssl/md5.h>


using namespace std;


int main()
{
    // create a socket
    // int client_socket;
    // client_socket=socket(AF_INET, SOCK_DGRAM, 0);

    // // specifying address for the socket
    // struct sockaddr_in server_address;
    // server_address.sin_family=AF_INET;
    // server_address.sin_port=htons(9999);
    // server_address.sin_addr.s_addr=INADDR_ANY;

    unsigned char data[1000000];
    int k=0;
    char ch;
    FILE *ptr=fopen("sample.txt", "r");
    while((ch=fgetc(ptr))!=EOF)
    {
    	data[k]=(unsigned char)ch;
    	k++;
    }
    data[k]='\0';
    // printf("%s", data);

    sendP(data, k);

	printf("done\n");
	return 0;
}