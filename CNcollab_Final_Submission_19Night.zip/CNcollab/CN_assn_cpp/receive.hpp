#include <bits/stdc++.h>
// #include "RelUDP.hpp"
// #include "Packet.hpp"
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pthread.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <unistd.h>
#include <fcntl.h>
#include <openssl/md5.h>


#define sz(QQQ) (int)QQQ.size()


void create_md5_hash(const unsigned char* data, unsigned char* digest, int length)
{
    MD5((unsigned char*)data, length, (unsigned char*)digest);  
}

void print_md5_hash(unsigned char* data)
{
    for(int i = 0; i < 16; i++)
       printf("%02x ",(unsigned int)data[i]);
    printf("\n");
}
int checkSum(Packet *p)
{
	unsigned char str[16];
	create_md5_hash(p->data, str, p->length);
	// print_md5_hash(p->checksum);
	// print_md5_hash(str);
	for(int i=0;i<16;i++)
		if(str[i]!=p->checksum[i])
			return 0;
	return 1;
}

void recv(unsigned char *output)
{
	int socketfd=socket(AF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in servaddr, cliaddr;
	memset(&cliaddr, 0, sizeof(cliaddr));
	memset(&servaddr, 0, sizeof(servaddr));

	servaddr.sin_family=AF_INET;
	servaddr.sin_port=htons(9090);
	servaddr.sin_addr.s_addr=INADDR_ANY;

	if(bind(socketfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    unsigned char buffer[64];

    socklen_t len=sizeof(cliaddr);

    // int flags = fcntl(socketfd, F_GETFL);
    // flags |= O_NONBLOCK;
    // fcntl(socketfd, F_SETFL, flags);
    // cout<<"started receiving\n";
    int n=-1;

	map<int, Packet> mp;
	while(1)
	{
		int n=recvfrom(socketfd, (unsigned char *)buffer, 64, 0, (struct sockaddr *) &cliaddr, &len);
		Packet p;
    	arrayToPacket(&p, buffer);
    	if(!checkSum(&p))
    	{
    		cout<<"checksum not matching\n";
    		Packet nck_packet;
    		memset(nck_packet.data, 0, sizeof(nck_packet));
    		nck_packet.ack=0;
    		nck_packet.nck=1;
    		nck_packet.seq_no=p.seq_no;
    		nck_packet.length=0;
    		unsigned char send_ack[64];
    		packetToArray(&nck_packet, send_ack);
    		sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
    		continue;
    	}
    	Packet ack_packet;
    	memset(ack_packet.data, 0, sizeof(ack_packet));
    	ack_packet.ack=1;
    	ack_packet.nck=0;
    	ack_packet.seq_no=p.seq_no;
    	ack_packet.length=0;
    	unsigned char send_ack[64];
    	packetToArray(&ack_packet, send_ack);
    	sendto(socketfd, (const unsigned char *)send_ack, 64, 0, (const struct sockaddr *) &cliaddr, sizeof(cliaddr));
    	char msg[]="TEKCAP TSAL";
    	p.data[p.length]='\0';
    	if(p.ack==1 && p.nck==1 && (strcmp((char*)p.data, msg)==0))
    	{
    		// cout<<"got the last packet\n";
    		break;
    	}
    	mp[p.seq_no]=p;
	}
	int k=0;
	for(auto it: mp)
	{
		for(int j=0;j<it.second.length;j++)
		{
			output[k]=it.second.data[j];
			k++;
		}
	}
	output[k]='\0';
}